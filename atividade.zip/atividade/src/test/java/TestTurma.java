import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class TestTurma {
    private Aluno aluno1, aluno2;
    private Disciplina disciplina;
    private Professor professor;
    private Turma turma;

    @Before
    public void setUp(){
        aluno1 = new Aluno("Diego");
        aluno2 = new Aluno("Alan");

        disciplina = new Disciplina("1", "DevOps");

        professor = new Professor("Iara");

        turma = new Turma(disciplina, professor);
    }

    @Test
    public void testAdicionarAlunoNaTurma() {

        turma.matricularAluno(aluno1);
        turma.matricularAluno(aluno2);

        assertTrue(turma.getAlunos().contains(aluno1));
        assertTrue(turma.getAlunos().contains(aluno2));
    }

}
